from testlight import *
from books import *


def tests():
    """
    tests for functions in books.py go here
    """
    # note: your setup function has not yet been run. this allows you to work
    #       with a smaller dataset for testing if you would like. or you
    #       can uncomment this line to have your setup() function run.
    # setup()
    pass


if __name__ == '__main__':
    tests()  # run tests if running file directly, as opposed to importing
