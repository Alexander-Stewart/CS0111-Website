import csv    # https://docs.python.org/3/library/csv.html
import random # https://docs.python.org/3/library/random.html
from dataclasses import dataclass

with open('books.csv', encoding='utf-8') as f:
    lines = list(csv.reader(f))  # loads lines of books.csv into list of lists

with open('genres.txt') as f:
    # loads list of genres to display on main page into list of strings
    # we have this list because otherwise there are too many books to display
    # and the website will get overloaded. Feel free to edit genres.txt!
    display_genres = list(map(lambda line: line[0], csv.reader(f)))


# frozen=True makes Books immutable (in other words, after you
# create them, you cannot change them). This allows you to use
# books as the keys in a hashtable if you want: {Book(...): 3, ...}
@dataclass(frozen=True)
class Book: 
    # ** do not modify this dataclass **
    title   : str
    author  : str
    genre   : str
    img_url : str
    rating  : float # out of 5 stars
    reviews : int   # number of reviews on amazon
    ident   : int   # identifier


def setup():
    """ procedure to setup any global variables (which must be defined
    above this function). """
    pass


def get_cart() -> list:
    """ return current representation of the cart. """
    return []


def get_recommendations() -> list:
    """
    return current recommendations, in order of how recommended the book is
    """
    return []


def get_book(identifier: int) -> Book:
    """ given a book id (integer), return the Book corresponding to that id """
    pass


def add_book_to_cart(ident: int):
    """ given the ident of a book, add the corresponding book to th
    cart. no return required. """
    pass


def remove_book_from_cart(ident: int):
    """ given the ident of a book, remove the corresponding book from
    the cart. no return required """
    pass


def buy_books_in_cart():
    """ purchase all books in cart. update cart, previous purchases,
    books, recommendations as required. no return required. """
    pass


def search_books(query: str) -> list:
    """ given a query string, return list of matching Books """
    return []


def get_book_dict() -> dict:
    """ return a dictionary of genre -> list of books.
    use random.sample to randomly choose some books to display
    for each genre. do not allow the number of books in any given
    genre to be greater than 25 (or the website will be overwhelmed)
    there should be one key for each genre in display_genres (loaded @ top) """
    return {}


def get_purchases() -> list:
    return []

